

import java.util.Scanner;
///*** house class ***/
class House implements Comparable<House> {
    private int rooms;
    private int baths;
    private double area;
    private String address;
    private double price;
    public String zipcode;
///* constructor */
    public House(int rooms, int baths, double area, String address, double price, String zipcode) {
        this.rooms = rooms;
        this.baths = baths;
        this.area = area;
        this.address = address;
        this.price = price;
        this.zipcode = zipcode;
    }

    // Getters and setters
    public int getRooms() { return rooms; }
    public void setRooms(int rooms) { this.rooms = rooms; }
    public int getBaths() { return baths; }
    public void setBaths(int baths) { this.baths = baths; }
    public double getArea() { return area; }
    public void setArea(double area) { this.area = area; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public String getZipcode() { return zipcode; }
    public void setZipcode(String zipcode) { this.zipcode = zipcode; }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        House house = (House) obj;
        return address.equals(house.address);
    }
//*** compareTo method ***
    @Override
    public int compareTo(House other) {
        return Double.compare(this.price, other.price);
    }
///* toString method */
    @Override
    public String toString() {
        return "Rooms: " + rooms + "\n" +
               "Baths: " + baths + "\n" +
               "Square Feet: " + area + "\n" +
               "Price: " + price + "\n" +
               "Zipcode: " + zipcode + "\n" +
               "Address: " + address + "\n" +
               "**********************";
    }
}
///* main class */
class ListNode {
    private House house;
    private ListNode next;

    public ListNode(House house) {
        this.house = house;
        this.next = null;
    }

    public ListNode() {
        // Empty constructor
    }

    public ListNode(House house, ListNode next) {
        this.house = house;
        this.next = next;
    }

    public House getHouse() {
        return house;
    }

    public ListNode getNext() {
        return next;
    }

    public void setNext(ListNode next) {
        this.next = next;
    }
}

interface List {
    void add(int rooms, int baths, double price, double area, String address, String zipcode);
    void add(int rooms, int baths, double area, String address, double price, String zipcode, int index);
    void remove(String address);
    int size();
    String toString();
    String list(int room);
    String list(int room, int bath);
    String list(String zipcode);
}
/**** LinkedList class ****/
class Zillow implements List {
    private ListNode head;
    private int size;

    public Zillow() {
        head = null;
        size = 0;
    }

    @Override
    public void add(int rooms, int baths, double price, double area, String address, String zipcode) {
        House newHouse = new House(rooms, baths, area, address, price, zipcode);
        ListNode newNode = new ListNode(newHouse);
        if (head == null) {
            head = newNode;
        } else {
            ListNode current = head;
            while (current.getNext() != null) {
                current = current.getNext();
            }
            current.setNext(newNode);
        }
        size++;
    }

    @Override
    public void add(int rooms, int baths, double area, String address, double price, String zipcode, int index) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("Invalid index");
        }
        House newHouse = new House(rooms, baths, area, address, price, zipcode);
        ListNode newNode = new ListNode(newHouse);
        if (index == 0) {
            newNode.setNext(head);
            head = newNode;
        } else {
            ListNode current = head;
            for (int i = 0; i < index - 1; i++) {
                current = current.getNext();
            }
            newNode.setNext(current.getNext());
            current.setNext(newNode);
        }
        size++;
    }
/*** remove method ***/
    @Override
    public void remove(String address) {
        if (head == null) return;
        if (head.getHouse().getAddress().equals(address)) {
            head = head.getNext();
            size--;
            return;
        }
        ListNode current = head;
        while (current.getNext() != null) {
            if (current.getNext().getHouse().getAddress().equals(address)) {
                current.setNext(current.getNext().getNext());
                size--;
                return;
            }
            current = current.getNext();
        }
    }
//*** size method ***
    @Override
    public int size() {
        return size;
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        ListNode current = head;
        while (current != null) {
            result.append(current.getHouse().toString()).append("\n");
            current = current.getNext();
        }
        return result.toString();
    }
/*** list method ***/
    @Override
    public String list(int room) {
        StringBuilder result = new StringBuilder();
        ListNode current = head;
        while (current != null) {
            if (current.getHouse().getRooms() == room) {
                result.append(current.getHouse().toString()).append("\n");
            }
            current = current.getNext();
        }
        return result.toString();
    }
/**** list method ***/
    @Override
    public String list(int room, int bath) {
        StringBuilder result = new StringBuilder();
        ListNode current = head;
        while (current != null) {
            if (current.getHouse().getRooms() == room && current.getHouse().getBaths() == bath) {
                result.append(current.getHouse().toString()).append("\n");
            }
            current = current.getNext();
        }
        return result.toString();
    }
/*** list method ***/
    @Override
    public String list(String zipcode) {
        StringBuilder result = new StringBuilder();
        ListNode current = head;
        while (current != null) {
            if (current.getHouse().getZipcode().equals(zipcode)) {
                result.append(current.getHouse().toString()).append("\n");
            }
            current = current.getNext();
        }
        return result.toString();
    }
/*** house method ***/
    public House getMostExpensiveHouse() {
        if (head == null) return null;
        House mostExpensive = head.getHouse();
        ListNode current = head.getNext();
        while (current != null) {
            if (current.getHouse().getPrice() > mostExpensive.getPrice()) {
                mostExpensive = current.getHouse();
            }
            current = current.getNext();
        }
        return mostExpensive;
    }

    public House getLeastExpensiveHouse() {
        if (head == null) return null;
        House leastExpensive = head.getHouse();
        ListNode current = head.getNext();
        while (current != null) {
            if (current.getHouse().getPrice() < leastExpensive.getPrice()) {
                leastExpensive = current.getHouse();
            }
            current = current.getNext();
        }
        return leastExpensive;
    }
}
/*** main method ***/
public class Main {
    public static void main(String[] args) {
        Zillow zillow = new Zillow();
        Scanner scanner = new Scanner(System.in);

        // Add some initial houses
        zillow.add(2, 3, 600000, 1200, "Halidon Drive", "95630");
        zillow.add(4, 3, 1700000, 3000, "Miners Cir", "95677");
        zillow.add(2, 2, 650000, 1400, "Albatroos Way", "95677");
        zillow.add(2, 3, 750000, 12500, "Taylor St", "95630");
        zillow.add(5, 4, 1650000, 2300, "Ridge View Drive", "95762");
        zillow.add(3, 2, 722000, 2300, "Vila Flor", "95630");
        zillow.add(2, 3, 710000, 1200, "Sahnnan Bay Drive", "95677");
        zillow.add(2, 3, 700000, 1100, "Canyon Drive", "95762");

        while (true) {
            System.out.println("*********************************************************");
            System.out.println("Enter 1 to list the houses based on the zipcode");
            System.out.println("Enter 2 to list the houses based on the number of the rooms");
            System.out.println("Enter 3 to list the houses with the number of rooms and baths");
            System.out.println("Enter 4 to remove a house from the list");
            System.out.println("Enter 5 to add a house to the list");
            System.out.println("Enter 6 to list all the houses");
            System.out.println("Enter 7 to list the most expensive house");
            System.out.println("Enter 8 to list the least expensive house");
            System.out.println("Enter 0 to exit");
            System.out.println("***************************************************");

            System.out.print("Select an option: ");
            int option = scanner.nextInt();
            scanner.nextLine(); // Consume newline
/**** switch case ****/
            switch (option) {
                case 0:
                    System.out.println("Exiting the program. Goodbye!");
                    return;
                case 1:
                    System.out.print("Enter the zipcode: ");
                    String zipcode = scanner.nextLine();
                    System.out.println(zillow.list(zipcode));
                    break;
                case 2:
                    System.out.print("Enter the number of the rooms: ");
                    int rooms = scanner.nextInt();
                    System.out.println(zillow.list(rooms));
                    break;
                case 3:
                    System.out.print("Enter the number of the rooms and the number of the baths: ");
                    int roomsFilter = scanner.nextInt();
                    int bathsFilter = scanner.nextInt();
                    System.out.println(zillow.list(roomsFilter, bathsFilter));
                    break;
                case 4:
                    System.out.print("Enter the address of the house: ");
                    String addressToRemove = scanner.nextLine();
                    zillow.remove(addressToRemove);
                    System.out.println("House removed (if found).");
                    break;
                case 5:
                    System.out.print("Enter the number of the rooms: ");
                    int newRooms = scanner.nextInt();
                    System.out.print("Enter the number of the baths: ");
                    int newBaths = scanner.nextInt();
                    System.out.print("Enter the price of the house: ");
                    double newPrice = scanner.nextDouble();
                    System.out.print("Enter the square feet of the house: ");
                    double newArea = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter the zip code: ");
                    String newZipcode = scanner.nextLine();
                    System.out.print("Enter the address: ");
                    String newAddress = scanner.nextLine();
                    zillow.add(newRooms, newBaths, newPrice, newArea, newAddress, newZipcode);
                    System.out.println("House added successfully.");
                    break;
                case 6:
                    System.out.println(zillow.toString());
                    break;
                case 7:
                    House mostExpensive = zillow.getMostExpensiveHouse();
                    if (mostExpensive != null) {
                        System.out.println(mostExpensive);
                    } else {
                        System.out.println("No houses in the list.");
                    }
                    break;
                case 8:
                    House leastExpensive = zillow.getLeastExpensiveHouse();
                    if (leastExpensive != null) {
                        System.out.println(leastExpensive);
                    } else {
                        System.out.println("No houses in the list.");
                    }
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}